<?php

namespace App\Http\Controllers;

use App\Models\UserTask;
use Illuminate\Http\Request;

class UserTaskController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(UserTask $userTask)
    {
        //
    }

    public function edit(UserTask $userTask)
    {
        //
    }

    public function update(Request $request, UserTask $userTask)
    {
        //
    }

    public function destroy(UserTask $userTask)
    {
        //
    }
}
