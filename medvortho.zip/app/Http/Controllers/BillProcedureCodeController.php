<?php

namespace App\Http\Controllers;

use App\Models\BillProcedureCode;
use Illuminate\Http\Request;

class BillProcedureCodeController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(BillProcedureCode $billprocedurecode)
    {
        //
    }

    public function edit(BillProcedureCode $billprocedurecode)
    {
        //
    }

    public function update(Request $request, BillProcedureCode $billprocedurecode)
    {
        //
    }

    public function destroy(BillProcedureCode $billprocedurecode)
    {
        //
    }
}
