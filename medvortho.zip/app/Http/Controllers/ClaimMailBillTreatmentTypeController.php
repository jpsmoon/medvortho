<?php

namespace App\Http\Controllers;

use App\Models\ClaimMailBillTreatmentType;
use Illuminate\Http\Request;

class ClaimMailBillTreatmentTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ClaimMailBillTreatmentType  $claimMailBillTreatmentType
     * @return \Illuminate\Http\Response
     */
    public function show(ClaimMailBillTreatmentType $claimMailBillTreatmentType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ClaimMailBillTreatmentType  $claimMailBillTreatmentType
     * @return \Illuminate\Http\Response
     */
    public function edit(ClaimMailBillTreatmentType $claimMailBillTreatmentType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ClaimMailBillTreatmentType  $claimMailBillTreatmentType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ClaimMailBillTreatmentType $claimMailBillTreatmentType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ClaimMailBillTreatmentType  $claimMailBillTreatmentType
     * @return \Illuminate\Http\Response
     */
    public function destroy(ClaimMailBillTreatmentType $claimMailBillTreatmentType)
    {
        //
    }
}
