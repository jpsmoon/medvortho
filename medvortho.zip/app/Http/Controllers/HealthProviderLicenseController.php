 <?php

namespace App\Http\Controllers;

use App\Models\Health_provider_licenses;
use Illuminate\Http\Request;

class HealthProviderLicensesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\health_provider_licenses  $health_provider_licenses
     * @return \Illuminate\Http\Response
     */
    public function show(health_provider_licenses $health_provider_licenses)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\health_provider_licenses  $health_provider_licenses
     * @return \Illuminate\Http\Response
     */
    public function edit(health_provider_licenses $health_provider_licenses)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\health_provider_licenses  $health_provider_licenses
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, health_provider_licenses $health_provider_licenses)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\health_provider_licenses  $health_provider_licenses
     * @return \Illuminate\Http\Response
     */
    public function destroy(health_provider_licenses $health_provider_licenses)
    {
        //
    }
}
