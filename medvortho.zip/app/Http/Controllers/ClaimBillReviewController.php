<?php

namespace App\Http\Controllers;

use App\Models\ClaimBillReview;
use Illuminate\Http\Request;

class ClaimBillReviewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\claim_bill_reviews  $claim_bill_reviews
     * @return \Illuminate\Http\Response
     */
    public function show(claim_bill_reviews $claim_bill_reviews)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\claim_bill_reviews  $claim_bill_reviews
     * @return \Illuminate\Http\Response
     */
    public function edit(claim_bill_reviews $claim_bill_reviews)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\claim_bill_reviews  $claim_bill_reviews
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, claim_bill_reviews $claim_bill_reviews)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\claim_bill_reviews  $claim_bill_reviews
     * @return \Illuminate\Http\Response
     */
    public function destroy(claim_bill_reviews $claim_bill_reviews)
    {
        //
    }
}
