<?php

namespace App\Http\Controllers;

use App\Models\ClaimMailAddress;
use Illuminate\Http\Request;

class ClaimMailAddressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\claim_mail_addresses  $claim_mail_addresses
     * @return \Illuminate\Http\Response
     */
    public function show(claim_mail_addresses $claim_mail_addresses)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\claim_mail_addresses  $claim_mail_addresses
     * @return \Illuminate\Http\Response
     */
    public function edit(claim_mail_addresses $claim_mail_addresses)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\claim_mail_addresses  $claim_mail_addresses
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, claim_mail_addresses $claim_mail_addresses)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\claim_mail_addresses  $claim_mail_addresses
     * @return \Illuminate\Http\Response
     */
    public function destroy(claim_mail_addresses $claim_mail_addresses)
    {
        //
    }
}
