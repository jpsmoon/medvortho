<div class="form-row form-group">
    <div class="form-holder col-md-4">
        <label for="" style="float:left;">   Insurance Payer      </label>
        <input type="text" name="ins_payer" id="ins_payer" class="form-control">
    </div>
    <div class="form-holder col-md-4">
        <label for="" style="float:left;">   Subscriber ID      </label>
        <input type="text" name="ins_subscriber" id="ins_subscriber" class="form-control" maxlength="25">
    </div>
    <div class="form-holder col-md-4">
        <label for="" style="float:left;">   Group No.      </label>
        <input type="text" name="ins_group_no" id="ins_group_no" class="form-control" maxlength="25">
    </div>
</div>
<div class="form-row form-group">
    <div class="form-holder col-md-4">
        <label for="" style="float:left;">   Deductible Amt.      </label>
        <input type="text" name="ins_deduct_amt" id="ins_deduct_amt" class="form-control" maxlength="10">
    </div>
    <div class="form-holder col-md-4">
        <label for="" style="float:left;">   Co-payment Amt.     </label>
        <input type="text" name="ins_copay_amt" id="ins_copay_amt" class="form-control" maxlength="10">
    </div>
    <div class="form-holder col-md-4">
        <label for="" style="float:left;">  Co-Insurance Amt.     </label>
        <input type="text" name="ins_coins_amt" id="ins_coins_amt" class="form-control" maxlength="10">
    </div>
</div>
<div class="form-row form-group">
    <div class="form-holder col-md-8">
        <label for="" style="float:left;">   Authorization Info.      </label>
        <textarea class="form-control" name="ins_authinfo" id="ins_authinfo" style="resize:none;" ></textarea>
    </div>
    <div class="form-holder col-md-4">
        <label for="" style="float:left;">   No. of visit authorized      </label>
        <input type="text" name="ins_no_of_visit" id="ins_no_of_visit" class="form-control" maxlength="3">
    </div>
</div> 