@extends('layouts.home-new-app')

@section('content')
    <div class="alert alert-danger">
        <h2>Access Denied</h2>
        <p>You do not have the required permissions to access this page.</p>
    </div>
@endsection
